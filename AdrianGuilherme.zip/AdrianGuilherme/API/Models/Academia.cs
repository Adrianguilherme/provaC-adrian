using Microsoft.AspNetCore.Mvc;
using Academia.Models;
using Academia.Data;


namespace AcademiaIMC.Models
{
    public class Academia : Models
    {
        private readonly Academia _context;

        public ImcController(Academia context)
        {
            _context = context;
        }

        
        public IActionResult Index()
        {
            return View(_context.Imcs.ToList());
        }

        
        public IActionResult Listar()
        {
            return View(_context.Imcs.ToList());
        }

        
        public IActionResult Criar()
        {
            ViewData["AlunoId"] = new SelectList(_context.Alunos, "Id", "Nome");
            return View();
        }

        
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Criar(Imc imc)
        {
            if (ModelState.IsValid)
            {
                imc.ImcValor = CalculateImc(imc.Altura, imc.Peso);
                imc.Classificacao = GetClassification(imc.ImcValor);

                _context.Add(imc);
                _context.SaveChanges();
                return RedirectToAction(nameof(Index));
            }
            ViewData["AlunoId"] = new SelectList(_context.Alunos, "Id", "Nome", imc.AlunoId);
            return View(imc);
        }

        
        public IActionResult Editar(int id)
        {
            var imc = _context.Imcs.Find(id);
            if (imc == null)
            {
                return NotFound();
            }
            ViewData["AlunoId"] = new SelectList(_context.Alunos, "Id", "Nome", imc.AlunoId);
            return View(imc);
        }

        
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Editar(int id, Imc imc)
        {
            if (id != imc.Id)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                imc.ImcValor = CalculateImc(imc.Altura, imc.Peso);
                imc.Classificacao = GetClassification(imc.ImcValor);

                _context.Update(imc);
                _context.SaveChanges();
                return RedirectToAction(nameof(Index));
            }
            ViewData["AlunoId"] = new SelectList(_context.Alunos, "Id", "Nome", imc.AlunoId);
            return View(imc);
        }

        
        public IActionResult Excluir(int id)
        {
            var imc = _context.Imcs.Find(id);
            if (imc == null)
            {
                return NotFound();
            }
            return View(imc);
        }

        
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public IActionResult ExcluirConfirmado(int id)
        {
            var imc = _context.Imcs.Find(id);
            _context.Remove(imc);
            _context.SaveChanges();
            return RedirectToAction(nameof(Index));
        }

        private decimal CalculateImc(decimal altura, decimal peso)
        {
            return peso / (altura * altura);
        }

        private string GetClassification(decimal imcValor)
        {
            if (imcValor < 18.5m)
            {
                return "Magro";
            }
            else if (imcValor < 25m)
            {
                return "Normal";
            }
            else if (imcValor < 30m)
            {
                return "Sobrepeso";
            }
            else
            {
                return "Obeso";
            }
        }
    }
}